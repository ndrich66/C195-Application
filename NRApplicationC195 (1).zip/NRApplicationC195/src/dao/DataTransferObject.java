package dao;

/** This is an interface. */
public interface DataTransferObject
{
    /** This is a getter. */
    long getID();
}
