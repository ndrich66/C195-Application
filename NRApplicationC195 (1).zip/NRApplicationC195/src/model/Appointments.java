package model;

import java.sql.Timestamp;
import java.time.LocalDateTime;

/** This class creates the appointment object. */
public class Appointments
{
    private int appointmentID;
    private String title;
    private String description;
    private String location;
    private String type;
    private LocalDateTime start;
    private LocalDateTime end;
    private LocalDateTime createdDate;
    private String createdBy;
    private Timestamp lastUpdate;
    private String lastUpdateBy;
    private int customerID;
    private int userID;
    private int contactID;

    /** This is a constructor for the appointment object.
     * @param appointmentID Integer
     * @param title String
     * @param description String
     * @param location String
     * @param type String
     * @param start LocalDateTime
     * @param end LocalDateTime
     * @param createdDate LocalDateTime
     * @param createdBy String
     * @param lastUpdate Timestamp
     * @param lastUpdateBy String
     * @param userID Integer
     * @param contactID Integer
     * @param customerID Integer */
    public Appointments (int appointmentID,
            String title,
            String description,
            String location,
            String type,
            LocalDateTime start,
            LocalDateTime end,
            LocalDateTime createdDate,
            String createdBy,
            Timestamp lastUpdate,
            String lastUpdateBy,
            int customerID,
            int userID,
            int contactID
    )
    {
        this.appointmentID = appointmentID;
        this.title = title;
        this.description = description;
        this.location = location;
        this.type = type;
        this.start = start;
        this.end = end;
        this.createdDate = createdDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdateBy = lastUpdateBy;
        this.customerID = customerID;
        this.userID = userID;
        this.contactID = contactID;
    }

    /** This is a constructor for the appointment object.
     * This constructor is used in the associated DAO.
     * @param appointmentID Integer
     * @param title String
     * @param description String
     * @param location String
     * @param type String
     * @param start LocalDateTime
     * @param end LocalDateTime
     * @param contactID Integer
     * @param customerID Integer
     * @param userID Integer */
    public Appointments(int appointmentID,
                        String title,
                        String description,
                        String location,
                        String type,
                        LocalDateTime start,
                        LocalDateTime end,
                        int customerID,
                        int userID,
                        int contactID)
    {
        this.appointmentID = appointmentID;
        this.title = title;
        this.description = description;
        this.location = location;
        this.type = type;
        this.start = start;
        this.end = end;
        this.customerID = customerID;
        this.userID = userID;
        this.contactID = contactID;
    }

    /** This is a constructor for the appointment object.
     * This constructor is used in the associated DAO.
     * @param apptType String
     * @param apptMonth Integer */
    public Appointments(String apptType, int apptMonth) {
        this.type = apptType;
        this.start = getStart().withMonth(apptMonth);
    }

/** This is a constructor for the appointment object.
 * This constructor is used in the associated DAO.
 * @param type String */
    public Appointments(String type) {
        this.type = type;
    }

    /** This is a getter for Appointment ID.
     * @return appointmentID */
    public int getAppointmentID()
    {
        return appointmentID;
    }

    /** This is a setter for Appointment ID.
     * @param appointmentID  Integer */
    public void setAppointmentID(int appointmentID)
    {
        this.appointmentID = appointmentID;
    }

    /** This is a getter for Title.
     * @return title */
    public String getTitle()
    {
        return title;
    }

    /** This is a setter for Title.
     * @param title String */
    public void setTitle(String title)
    {
        this.title = title;
    }

    /** This is a getter for Description.
     * @return description */
    public String getDescription()
    {
        return description;
    }

    /** This is a setter for description.
     * @param description String */
    public void setDescription(String description)
    {
        this.description = description;
    }

    /** This is a getter for location.
     * @return location */
    public String getLocation()
    {
        return location;
    }

    /** This is a setter for location.
     * @param location String */
    public void setLocation(String location)
    {
        this.location = location;
    }

    /** This is a getter for type.
     * @return type */
    public String getType()
    {
        return type;
    }

    /** This is a setter for type.
     * @param type String */
    public void setType(String type)
    {
        this.type = type;
    }

    /** This is a getter for start.
     * @return start */
    public LocalDateTime getStart()
    {
        return start;
    }

    /** This is a setter for start.
     * @param start LocalDateTime */
    public void setStart(LocalDateTime start)
    {
        this.start = start;
    }

    /** This is a getter for end.
     * @return end */
    public LocalDateTime getEnd()
    {
        return end;
    }

    /** This is a setter for end.
     * @param end LocalDateTime */
    public void setEnd(LocalDateTime end)
    {
        this.end = end;
    }

    /** This is a getter for created date.
     * @return createdDate */
    public LocalDateTime getCreatedDate()
    {
        return createdDate;
    }

    /** This is a setter for created date.
     * @param createdDate LocalDateTime */
    public void setCreatedDate(LocalDateTime createdDate)
    {
        this.createdDate = createdDate;
    }

    /** This is a getter for created by.
     * @return createdBy */
    public String getCreatedBy()
    {
        return createdBy;
    }

    /** This is a setter for created by.
     * @param createdBy String */
    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }

    /** This is a getter for created by.
     * @return createdBy */
    public Timestamp getLastUpdate()
    {
        return lastUpdate;
    }

    /** This is a setter for last update.
     * @param lastUpdate Timestamp */
    public void setLastUpdate(Timestamp lastUpdate)
    {
        this.lastUpdate = lastUpdate;
    }

    /** This is a getter for last update by.
     * @return lastUpdateBy */
    public String getLastUpdateBy()
    {
        return lastUpdateBy;
    }

    /** This is a setter for last update by.
     * @param lastUpdateBy String */
    public void setLastUpdateBy(String lastUpdateBy)
    {
        this.lastUpdateBy = lastUpdateBy;
    }

    /** This is a getter for last customer ID.
     * @return customerID */
    public int getCustomerID()
    {
        return customerID;
    }

    /** This is a setter for last customer ID.
     * @param customerID Integer */
    public void setCustomerID(int customerID)
    {
        this.customerID = customerID;
    }

    /** This is a getter for last user ID.
     * @return userID */
    public int getUserID()
    {
        return userID;
    }

    /** This is a setter for last user ID.
     * @param userID Integer */
    public void setUserID(int userID)
    {
        this.userID = userID;
    }

    /** This is a getter for last contact ID.
     * @return contactID */
    public int getContactID()
    {
        return contactID;
    }

    /** This is a setter for last contact ID.
     * @param contactID Integer */
    public void setContactID(int contactID)
    {
        this.contactID = contactID;
    }

    /** This is an override method.
     * This method does a toString for type. */
    @Override
    public String toString() {
        return type;
    }
}