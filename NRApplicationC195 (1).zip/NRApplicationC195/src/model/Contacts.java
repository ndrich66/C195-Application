package model;

/** This class creates the Contacts object. */
public class Contacts
{
    private int contactID;
    private String contactName;
    private String email;

    /** This is a constructor for the contact object.
     * @param contactID Integer
     * @param contactName String
     * @param email String */
    public Contacts(
            int contactID,
            String contactName,
            String email)
    {
        this.contactID = contactID;
        this.contactName = contactName;
        this.email = email;
    }

    /** This is a getter for the contact ID.
     * @return contactID */
    public int getContactID() {
        return contactID;
    }

    /** This is a setter for the contact ID.
     * @param  contactID Integer */
    public void setContactID(int contactID)
    {
        this.contactID = contactID;
    }

    /** This is a getter for the contact name.
     * @return contactName */
    public String getContactName()
    {
        return contactName;
    }

    /** This is a setter for the contact name.
     * @param  contactName String */
    public void setContactName(String contactName)
    {
        this.contactName = contactName;
    }

    /** This is a getter for the email.
     * @return email */
    public String getEmail()
    {
        return email;
    }

    /** This is a setter for the email.
     * @param  email String */
    public void setEmail(String email)
    {
        this.email = email;
    }

    /** This is an override method.
     * This method does a toString for contactID and contactName. */
    @Override
    public String toString() {
        return contactID + ": " + contactName;
    }
}
