package model;

import java.sql.Timestamp;
import java.time.LocalDateTime;

/** This class creates the User object. */
public class User {
    private int userID;
    private String userName;
    private String password;
    private LocalDateTime createdDate;
    private String createdBy;
    private Timestamp lastUpdate;
    private String lastUpdateBy;

    /** This is a constructor for the user object.
     * @param userID Integer
     * @param userName String
     * @param password String
     * @param createdDate LocalDateTime
     * @param createdBy String
     * @param lastUpdate Timestamp
     * @param lastUpdateBy String */
    public User(
            int userID,
            String userName,
            String password,
            LocalDateTime createdDate,
            String createdBy,
            Timestamp lastUpdate,
            String lastUpdateBy)
    {
        this.userID = userID;
        this.userName = userName;
        this.password = password;
        this.createdDate = createdDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdateBy = lastUpdateBy;
    }

    /** This is a constructor for the user object.
     * @param userID Integer
     * @param userName String
     * @param password String */
    public User(int userID, String userName, String password) {
        this.userID = userID;
        this.userName = userName;
        this.password = password;
    }

    /** This is an empty constructor.
     * This is here for the user object created in Main. */
    public User() { }

    /** This is a getter for the user ID.
     * @return userID */
    public long getUserID() {
        return userID;
    }

    /** This is a setter for the user ID.
     * @param userID Integer */
    public void setUserID(int userID) {
        this.userID = userID;
    }

    /** This is a getter for the user name.
     * @return userName */
    public String getUserName() {
        return userName;
    }

    /** This is a setter for the user name.
     * @param userName String */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /** This is a getter for the password.
     * @return password */
    public String getPassword() {
        return password;
    }

    /** This is a setter for the password.
     * @param password String */
    public void setPassword(String password) {
        this.password = password;
    }

    /** This is a getter for the created date.
     * @return createdDate */
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    /** This is a setter for the created date.
     * @param createdDate LocalDateTime */
    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    /** This is a getter for the created by.
     * @return createdBy */
    public String getCreatedBy() {
        return createdBy;
    }

    /** This is a setter for the created by.
     * @param createdBy String */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /** This is a getter for the last update.
     * @return lastUpdate */
    public Timestamp getLastUpdate() {
        return lastUpdate;
    }

    /** This is a setter for the last update.
     * @param lastUpdate Timestamp */
    public void setLastUpdate(Timestamp lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    /** This is a getter for the last update by.
     * @return lastUpdateBy */
    public String getLastUpdateBy() {
        return lastUpdateBy;
    }

    /** This is a setter for the last update by.
     * @param lastUpdateBy String */
    public void setLastUpdateBy(String lastUpdateBy) {
        this.lastUpdateBy = lastUpdateBy;
    }

    /** This is an override method.
     * This method does a toString for user ID and user name. */
    @Override
    public String toString() {
        return userID + ": " + userName;
    }
}