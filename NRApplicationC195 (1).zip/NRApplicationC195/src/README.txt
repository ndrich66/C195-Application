This project is titled NRApplicationC195. This project's purpose is to schedule appointments.

By: Nicole Richards, nrich66@wgu.edu, Application Version 1.4, 04/29/2023

IntelliJ Community Edition 2021.1.3, Java JDK 17.0.4.1, Java Version 17.0.4

After initiating the program, you will be taken to a login screen. After completing that, you will be taken to the appointment scheduler main page.
There is a appointment table with associated buttons, and customer table with associated buttons. These buttons will lead you to a page where you can
add or modify the information on the tables, and in the database. There are delete buttons on the main page that allows you to delete directly off the
tables without switching screens. There is a reports button that takes you to the associated page. There are also radio buttons on the main page that
filter the data on the appointments table to display appointments by week, by month, and to all appointments.

The additional report I chose was to display contact details, this can be filtered by a combo box to find a specific contact. This will be useful with
the addition of more contacts.

mysql-connector-java-8.1.31